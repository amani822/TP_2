scores={
    "Alice":88,
    "Bob":95,
    "Charlie":90
}
name="Alice"
biggest=scores[name]
for B in scores:
    if scores[B]>biggest:
        biggest= scores[B]
        name=B
print("the student with the highest score is: ",name )
print ("the highest score is: ", biggest)

    


    