import turtle
H=turtle.Turtle()
H.speed(3)
H.pensize(5)
H.shape("turtle")
colors=["yellow","red", "black" ,"purple","green","orange"]
for i in range (6):
  H.color(colors[i])
  H.forward(int(input("enter the forward steps: ")))
  H.right(int(input("enter the right steps: ")))
