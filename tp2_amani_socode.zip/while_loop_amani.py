x=23
N=0
while N!=x:
    N=int(input("guess the secret number: "))
    if N>x:
        print("too high!try again.")
    elif N<x:
        print("too low! try again.")
    else:
        print("congratulation,you've guessed the number")
